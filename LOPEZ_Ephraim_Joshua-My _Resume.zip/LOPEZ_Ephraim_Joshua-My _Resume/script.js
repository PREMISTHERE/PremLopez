const nameElement = document.querySelector(".sec1_name");
let isFadingIn = true;
let lastScrollPosition = window.scrollY;

window.addEventListener("scroll", () => {
  const currentScrollPosition = window.scrollY;
  const scrollDelta = Math.abs(currentScrollPosition - lastScrollPosition);

  if (scrollDelta > 5) {
    if (currentScrollPosition > lastScrollPosition) {
      isFadingIn = false;
    } else {
      isFadingIn = true;
    }
  }

  const opacity = isFadingIn ? Math.min(scrollDelta / 200, 5) : 5 - Math.min(scrollDelta / 200, 5);

  nameElement.style.opacity = opacity;

  lastScrollPosition = currentScrollPosition;
});